public class WiFiDriver {
	 
		    public static void main (String[] args) {

		        System.out.println("If you have a problem with internet connectivity, this WiFi Diagnosis might work.\n");

		        WifiDiagonosis diagnosis = new WifiDiagonosis();
		        
		        diagnosis.troubleShootWiFi();
		    }
		}
