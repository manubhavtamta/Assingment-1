import java.util.Scanner;

public class WifiDiagonosis {

	public void troubleShootWiFi() {
		
		Scanner sc = new Scanner(System.in);
		
		//This is how the first step going to be 
		System.out.println("First step: reboot your computer");
		System.out.print("Are you able to connect with the internet? (yes or no): ");
		String choice = sc.nextLine().trim();
		while(!choice.equalsIgnoreCase("yes") && !choice.equalsIgnoreCase("no")) {
		
		System.out.println("Please enter yes or no!\n");
		System.out.print("Are you able to connect with the internet? (yes or no): ");
		choice = sc.nextLine().trim();
		}
		if(choice.equalsIgnoreCase("yes"))
		{
		System.out.println("Rebooting your computer seemed to work");
		return;
		
		}
		
		//second step 
		System.out.println("Second Step: reboot your router");
		System.out.println("Are you able to connect with the internet? (yes or no): ");
		String Choice = sc.nextLine().trim();
		while (!choice.equalsIgnoreCase("yes") && !choice.equalsIgnoreCase("no")) {
			System.out.println("Please enter yes or no!\n");
			System.out.print("Are you able to connect with the internet? (yes or no): ");
			choice = sc.nextLine();
		}
		if (choice.equalsIgnoreCase("yes")) {
			System.out.println("Rebooting your router seemed to work. ");
		}
		//third step
		System.out.println("Third Step: Make sure the cables to your router are plugged in firmly and your router is getting power. ");
		System.out.println("Are you able to connect with the internet? (yes or no): ");
		    choice = sc.nextLine();
		while(!choice.equalsIgnoreCase("yes") && !choice.equalsIgnoreCase("no")) {
			System.out.println("Are you able to connect with the internet? (yes or no): ");
			choice = sc.nextLine();
		}
		if(choice.equalsIgnoreCase("yes"))
		{
			System.out.println("Checking the router's cables seemed to work. ");
		}
		//fourth step
		System.out.println("Fourth step: move your computer closer to your router.");
		System.out.println("Are you able to connect with the internet? (yes or no): ");
		choice = sc.nextLine();
		while(!choice.equalsIgnoreCase("yes") && !choice.equalsIgnoreCase("no")) {
			System.out.println("Are you able to connect with the internet? (yes or no): ");
			choice = sc.nextLine();
		}
		if(choice.equalsIgnoreCase("yes")) {
			System.out.println("Moving your computer close to router seemed work. ");
		}
		//fifth step
		System.out.println("Fifth step: contact your ISP ");
		System.out.println("Make sure your ISP is hooked up to your router.");
	}

	
}
